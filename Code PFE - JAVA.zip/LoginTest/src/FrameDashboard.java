import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;

public class FrameDashboard extends JFrame {

	private JPanel contentPane;

	private Image img_logo = new ImageIcon(FrameLogin.class.getResource("res/logo.png")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
	private Image img_home = new ImageIcon(FrameLogin.class.getResource("res/home1.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_profits = new ImageIcon(FrameLogin.class.getResource("res/profits.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_orders = new ImageIcon(FrameLogin.class.getResource("res/empl.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_cutomers = new ImageIcon(FrameLogin.class.getResource("res/pngtree-joystick-icon-for-your-project-png-image_4817857.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_settings = new ImageIcon(FrameLogin.class.getResource("res/settings.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_sign_out = new ImageIcon(FrameLogin.class.getResource("res/sign_out.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);

	private PanelHome panelHome;
	private PanelProfits panelProfits ; 
	private PanelOrder panelOrder;
	private PanelCustomres panelCustomers ; 
	private PanelSettings panelSettings ;

	private Component pnaelCustomer;

	private Component PanelSettings; 
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameDashboard frame = new FrameDashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrameDashboard() {
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 811, 418);
		setUndecorated(true);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 139, 139));
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 128), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panelHome = new PanelHome();
		panelProfits = new PanelProfits();
		
		panelOrder = new PanelOrder();
//		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getRootPane());
//		panelCustomers = new PanelCustomres(layout, getContentPane());
		panelCustomers = new PanelCustomres();
		
		panelSettings = new PanelSettings(); 
		
		
		JPanel paneSettings = new JPanel();
		paneSettings.setForeground(new Color(47, 79, 79));
		paneSettings.setBackground(new Color(47, 79, 79));
		paneSettings.setBounds(0, 0, 249, 418);
		contentPane.add(paneSettings);
		paneSettings.setLayout(null);
		
		JLabel lbllconLogo = new JLabel("");
		lbllconLogo.setForeground(new Color(47, 79, 79));
		lbllconLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconLogo.setBounds(10, 11, 229, 126);
		lbllconLogo.setIcon(new ImageIcon(img_logo));
		paneSettings.add(lbllconLogo);
		
		JPanel paneHome = new JPanel();
		paneHome.addMouseListener(new PanelButtonMouseAdapter(paneHome) {
			@Override
			public void mouseClicked(MouseEvent e ) {
				menuClicked(panelHome);
			}
		});
		paneHome.setBackground(new Color(47, 79, 79));
		paneHome.setForeground(new Color(47, 79, 79));
		paneHome.setBounds(0, 140, 249, 40);
		paneSettings.add(paneHome);
		paneHome.setLayout(null);
		
		JLabel lblHome = new JLabel("HOME");
		lblHome.setForeground(new Color(255, 255, 255));
		lblHome.setFont(new Font("Dialog", Font.BOLD, 14));
		lblHome.setBounds(76, 11, 163, 18);
		paneHome.add(lblHome);
		
		JLabel lbllconHome = new JLabel("");
		lbllconHome.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconHome.setBounds(26, 0, 40, 40);
		lbllconHome.setIcon(new ImageIcon(img_home));
		paneHome.add(lbllconHome);
		
		JPanel paneProfits = new JPanel();
		paneProfits.addMouseListener(new PanelButtonMouseAdapter(paneProfits) {
			public void mouseClicked(MouseEvent e ) {
				menuClicked(panelProfits);
			}
		});
		paneProfits.setBackground(new Color(47, 79, 79));
		paneProfits.setForeground(new Color(47, 79, 79));
		paneProfits.setBounds(0, 180, 249, 40);
		paneSettings.add(paneProfits);
		paneProfits.setLayout(null);
		
		JLabel lblProfits = new JLabel("EQUIPMENT");
		lblProfits.setForeground(Color.WHITE);
		lblProfits.setFont(new Font("Dialog", Font.BOLD, 14));
		lblProfits.setBounds(76, 11, 163, 18);
		paneProfits.add(lblProfits);
		
		JLabel lbllconProfits = new JLabel("");
		lbllconProfits.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconProfits.setBounds(26, 0, 40, 40);
		lbllconProfits.setIcon(new ImageIcon(img_profits));
		paneProfits.add(lbllconProfits);
		
		JPanel paneOrders = new JPanel();
		paneOrders.addMouseListener(new PanelButtonMouseAdapter(paneOrders) {
			public void mouseClicked(MouseEvent e ) {
				menuClicked(panelOrder);
			}
		});
		paneOrders.setBackground(new Color(47, 79, 79));
		paneOrders.setForeground(new Color(47, 79, 79));
		paneOrders.setBounds(0, 220, 249, 40);
		paneSettings.add(paneOrders);
		paneOrders.setLayout(null);
		
		JLabel lblOrders = new JLabel("EMPLACEMNT");
		lblOrders.setForeground(Color.WHITE);
		lblOrders.setFont(new Font("Dialog", Font.BOLD, 14));
		lblOrders.setBounds(76, 11, 163, 18);
		paneOrders.add(lblOrders);
		
		JLabel lbllconOrder = new JLabel("");
		lbllconOrder.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconOrder.setBounds(26, 0, 40, 40);
		lbllconOrder.setIcon(new ImageIcon(img_orders));
		paneOrders.add(lbllconOrder);
		
		JPanel pnaeCustomer = new JPanel();
		pnaeCustomer.addMouseListener(new PanelButtonMouseAdapter(pnaeCustomer) {
			public void mouseClicked(MouseEvent e ) {
				menuClicked(panelCustomers);
			}
		});
		pnaeCustomer.setBackground(new Color(47, 79, 79));
		pnaeCustomer.setForeground(new Color(47, 79, 79));
		pnaeCustomer.setBounds(0, 260, 249, 40);
		paneSettings.add(pnaeCustomer);
		pnaeCustomer.setLayout(null);
		
		JLabel lblCustomers = new JLabel("COMMANDE");
		lblCustomers.setForeground(Color.WHITE);
		lblCustomers.setFont(new Font("Dialog", Font.BOLD, 14));
		lblCustomers.setBounds(76, 11, 163, 18);
		pnaeCustomer.add(lblCustomers);
		
		JLabel lbllconCustomers = new JLabel("");
		lbllconCustomers.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconCustomers.setBounds(27, 0, 40, 40);
		lbllconCustomers.setIcon(new ImageIcon(img_cutomers));
		pnaeCustomer.add(lbllconCustomers);
		
		JPanel panesettings = new JPanel();
		panesettings.addMouseListener(new PanelButtonMouseAdapter(panesettings) {
			public void mouseClicked(MouseEvent e ) {
				menuClicked(panelSettings);
			}
		});
		panesettings.setBackground(new Color(47, 79, 79));
		panesettings.setForeground(new Color(47, 79, 79));
		panesettings.setBounds(0, 300, 249, 40);
		paneSettings.add(panesettings);
		panesettings.setLayout(null);
		
		JLabel lblSettings = new JLabel("SETTINGS");
		lblSettings.setForeground(Color.WHITE);
		lblSettings.setFont(new Font("Dialog", Font.BOLD, 14));
		lblSettings.setBounds(76, 11, 163, 18);
		panesettings.add(lblSettings);
		
		JLabel lbllconsettings = new JLabel("");
		lbllconsettings.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconsettings.setBounds(33, 0, 40, 40);
		lbllconsettings.setIcon(new ImageIcon(img_settings));
		panesettings.add(lbllconsettings);
		
		JPanel paneSigneout = new JPanel();
		paneSigneout.addMouseListener(new PanelButtonMouseAdapter(paneSigneout) {
			public void mouseClicked(MouseEvent e ) {
				if(JOptionPane.showConfirmDialog(null, "Are you sure you want to sign out ?") == 0) {
					FrameLogin frameLogin = new FrameLogin();
					frameLogin.setVisible(true);
					FrameDashboard.this.dispose();
				}
				
			}
		});
		paneSigneout.setBackground(new Color(47, 79, 79));
		paneSigneout.setForeground(new Color(0, 139, 139));
		paneSigneout.setBounds(0, 340, 249, 40);
		paneSettings.add(paneSigneout);
		paneSigneout.setLayout(null);
		
		JLabel lblSigneOut = new JLabel("SIGN OUT");
		lblSigneOut.setForeground(Color.WHITE);
		lblSigneOut.setFont(new Font("Dialog", Font.BOLD, 14));
		lblSigneOut.setBounds(76, 11, 163, 18);
		paneSigneout.add(lblSigneOut);
		
		JLabel lbllconsign_out = new JLabel("");
		lbllconsign_out.setHorizontalAlignment(SwingConstants.CENTER);
		lbllconsign_out.setBounds(32, 0, 40, 40);
		lbllconsign_out.setIcon(new ImageIcon(img_sign_out));
		paneSigneout.add(lbllconsign_out);
		
		JLabel lblExit = new JLabel("X");
		lblExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblExit.setForeground(Color.WHITE);
		lblExit.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
		lblExit.setBounds(791, 0, 20, 20);
		lblExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
if(JOptionPane.showConfirmDialog(null, "Are you sure you want to close this application ? ", "Confirmation", JOptionPane.YES_NO_OPTION) == 0) {
					FrameDashboard.this.dispose();
				}
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				lblExit.setForeground(Color.RED);
			}
			public void mouseExited(MouseEvent arg0) {
				lblExit.setForeground(Color.WHITE);
			}
		});
		contentPane.add(lblExit);
		
		JPanel panelMainContent = new JPanel();
		panelMainContent.setBounds(259, 11, 538, 396);
		contentPane.add(panelMainContent);
		panelMainContent.setLayout(null);
		
		panelMainContent.add(panelHome);
		panelMainContent.add(panelProfits);
		panelMainContent.add(panelOrder);
		panelMainContent.add(panelCustomers);
		panelMainContent.add(panelSettings);

		
		
		menuClicked(panelHome);
		
	}
	public void menuClicked(JPanel panel) {
		panelHome.setVisible(false);
		panelProfits.setVisible(false);
		panelOrder.setVisible(false);
		panelCustomers.setVisible(false);
		panelSettings.setVisible(false);
		
		panel.setVisible(true);
	}
	private class PanelButtonMouseAdapter extends MouseAdapter{
		
		JPanel panel;
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel; 
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(112,128,144));
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(47,79,79));

		}
		@Override
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(60,179,113));

		}
		@Override
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(112,128,144));

		}
	}
	
}
