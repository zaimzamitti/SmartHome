import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;

import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import java.awt.Rectangle;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JSpinner;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField Username;
	private JTextField mail;

	private Image img_username = new ImageIcon(FrameLogin.class.getResource("res/man.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_mail = new ImageIcon(FrameLogin.class.getResource("res/mail.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_password = new ImageIcon(FrameLogin.class.getResource("res/padlock.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_log_in = new ImageIcon(FrameLogin.class.getResource("res/icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
	private Image img_logo = new ImageIcon(FrameLogin.class.getResource("res/logo.png")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
	private JPasswordField Password;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 430);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(Username.getText().equals("Username")) {
					Username.setText("");
				}
				else {
					Username.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(Username.getText().equals(""))
					Username.setText("Username");
			}
		});
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(87, 116, 250, 40);
		contentPane.add(panel);
		
		Username = new JTextField();
		Username.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(Username.getText().equals("Username")) {
					Username.setText("");
				}
				else {
					Username.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(Username.getText().equals(""))
					Username.setText("Username");
			}
		});
		Username.setText("Username");
		Username.setFont(new Font("Arial", Font.PLAIN, 12));
		Username.setColumns(10);
		Username.setBorder(null);
		Username.setBounds(10, 11, 170, 20);
		panel.add(Username);
		
		JLabel lblIconUsername = new JLabel("");
		lblIconUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconUsername.setBounds(210, 0, 40, 40);
		lblIconUsername.setIcon(new ImageIcon(img_username));
		panel.add(lblIconUsername);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(87, 218, 250, 40);
		contentPane.add(panel_1);
		
		JLabel lblIconPassword = new JLabel("");
		lblIconPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconPassword.setBounds(210, 0, 40, 40);
		lblIconPassword.setIcon(new ImageIcon(img_password));
		panel_1.add(lblIconPassword);
		
		JLabel lblIconUsername_2 = new JLabel("");
		lblIconUsername_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconUsername_2.setBounds(210, 0, 40, 40);
		panel_1.add(lblIconUsername_2);
		
		Password = new JPasswordField();
		Password.setBorder(null);
		Password.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(Password.getText().equals("Password")) {
					Password.setEchoChar('*');
					Password.setText("");
				}
				else {
					Password.selectAll();
				}
			}
			
			@Override
			public void focusLost(FocusEvent e) {
				if(Password.getText().equals(""))
					Password.setText("Password");
			}
		});
		Password.setText("*********");
		Password.setBounds(10, 11, 125, 20);
		panel_1.add(Password);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(87, 167, 250, 40);
		contentPane.add(panel_2);
		
		mail = new JTextField();
		mail.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(mail.getText().equals("mail")) {
					mail.setText("");
				} else {
					mail.selectAll();
				}
			}
			
			@Override
			public void focusLost(FocusEvent e) {
				if(mail.getText().equals(""))
					mail.setText("mail");
			}
		});
		mail.setText("Mail");
		mail.setFont(new Font("Arial", Font.PLAIN, 12));
		mail.setColumns(10);
		mail.setBorder(null);
		mail.setBounds(10, 11, 170, 20);
		panel_2.add(mail);
		
		JLabel lblIconMail = new JLabel("");
		lblIconMail.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconMail.setIcon(new ImageIcon(img_mail));
		lblIconMail.setBounds(210, 0, 40, 40);
		panel_2.add(lblIconMail);
		
		JLabel lblIconbutton = new JLabel("");
		lblIconbutton.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconbutton.setBounds(114, 248, 39, 40);
		contentPane.add(lblIconbutton);
		
		JLabel lblIconLogo = new JLabel("");
		lblIconLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconLogo.setBounds(119, 11, 190, 94);
		lblIconLogo.setIcon(new ImageIcon(img_logo));
		contentPane.add(lblIconLogo);
		
		JPanel pnlBtnLogin = new JPanel();
		pnlBtnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver"); 
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
					PreparedStatement ps = conn.prepareStatement("insert into tblogin(UserName,mail,Password ) values (?,?,?);");
					ps.setString(1, Username.getText());
					ps.setString(2, mail.getText());
					ps.setString(3, Password.getText());
					int x = ps.executeUpdate();
					if (x == 0) {
	                       JOptionPane.showMessageDialog(null, "This is alredy exist");
	                    	
	                    } else {
	                        JOptionPane.showMessageDialog(null,
	                             "Your account is sucessfully created");
	                    	
	                    }
	                    conn.close();
				} catch (Exception e) {
					System.out.print(e);
				}
			}
		});
		pnlBtnLogin.setLayout(null);
		pnlBtnLogin.setBackground(new Color(47, 79, 79));
		pnlBtnLogin.setBounds(87, 284, 255, 50);
		contentPane.add(pnlBtnLogin);
		
		JLabel lblRegister = new JLabel("REGISTER");
		lblRegister.setForeground(Color.WHITE);
		lblRegister.setFont(new Font("Arial", Font.BOLD, 14));
		lblRegister.setBackground(Color.PINK);
		lblRegister.setBounds(105, 11, 90, 28);
		pnlBtnLogin.add(lblRegister);
		
		JLabel lblIconLogin = new JLabel("");
		lblIconLogin.setBounds(53, 0, 63, 50);
		lblIconLogin.setIcon(new ImageIcon(img_log_in));
		pnlBtnLogin.add(lblIconLogin);
		
		JLabel lblClickHereTo = new JLabel("Click here to login ");
		lblClickHereTo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				FrameLogin fr = new FrameLogin(); 
				fr.setVisible(true);
				
			    
			}
		});
		lblClickHereTo.setForeground(new Color(128, 0, 0));
		lblClickHereTo.setHorizontalAlignment(SwingConstants.CENTER);
		lblClickHereTo.setFont(new Font("Arial", Font.PLAIN, 13));
		lblClickHereTo.setBounds(114, 345, 195, 21);
		contentPane.add(lblClickHereTo);
	}
}
