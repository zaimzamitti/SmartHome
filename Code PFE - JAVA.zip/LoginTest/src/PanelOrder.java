import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;

public class PanelOrder extends JPanel {

	private Image img_plan = new ImageIcon(FrameLogin.class.getResource("res/plan.png")).getImage().getScaledInstance(300, 250, Image.SCALE_SMOOTH);
 
	public PanelOrder() {
		setBackground(new Color(255, 255, 255));

		setBounds(0,0,538,396);
		setLayout(null);
		
		JLabel lblThisIsOrder = new JLabel("The House's plan : ");
		lblThisIsOrder.setForeground(new Color(255, 0, 255));
		lblThisIsOrder.setHorizontalAlignment(SwingConstants.CENTER);
		lblThisIsOrder.setFont(new Font("Algerian", Font.ITALIC, 24));
		lblThisIsOrder.setBounds(-20, 11, 347, 69);
		add(lblThisIsOrder);
		
		JLabel plan = new JLabel("");
		plan.setForeground(new Color(255, 255, 255));
		plan.setBackground(new Color(255, 255, 255));
		plan.setHorizontalAlignment(SwingConstants.CENTER);
		plan.setIcon(new ImageIcon(img_plan));
		plan.setBounds(10, 71, 518, 314);
		add(plan);
	}
}
