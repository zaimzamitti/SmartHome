import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Color;

public class PanelHome extends JPanel {

	private Image img_home = new ImageIcon(FrameLogin.class.getResource("res/unnamed.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);

	public PanelHome() {
		setBackground(new Color(0, 128, 128));
		setBounds(0,0,538,396);
		setLayout(null);
		setVisible(true);
		
		JLabel lblThisIsHome = new JLabel("");
		lblThisIsHome.setIcon(new ImageIcon(img_home));
		lblThisIsHome.setHorizontalAlignment(SwingConstants.CENTER);
		lblThisIsHome.setFont(new Font("Tahoma", Font.BOLD, 37));
		lblThisIsHome.setBounds(103, 11, 370, 135);
		add(lblThisIsHome);
		
		JLabel lblHomeTxt = new JLabel("Welcome to your Smart Home Personal control - anywhere, anytime : ");
		lblHomeTxt.setForeground(new Color(255, 255, 255));
		lblHomeTxt.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		lblHomeTxt.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomeTxt.setBounds(34, 152, 476, 34);
		add(lblHomeTxt);
		
		JLabel textHome = new JLabel("Smart home : We were still talking about home automation a few years ago. We are now");
		textHome.setForeground(new Color(255, 255, 255));
		textHome.setBounds(20, 175, 518, 34);
		add(textHome);
		
		JLabel textHome_1 = new JLabel("talking about Smart Home with the evolution of connected objects and the artificial");
		textHome_1.setForeground(new Color(255, 255, 255));
		textHome_1.setBounds(40, 197, 498, 40);
		add(textHome_1);
		
		JLabel textHome_1_1 = new JLabel("features for the well-being of all. All these little gestures that had to be repeated, you can");
		textHome_1_1.setForeground(new Color(255, 255, 255));
		textHome_1_1.setBounds(30, 221, 508, 42);
		add(textHome_1_1);
		
		JLabel textHome_1_1_1 = new JLabel("do them easily from your chair and, even, away from home.Even after your departure,");
		textHome_1_1_1.setForeground(new Color(255, 255, 255));
		textHome_1_1_1.setBounds(40, 248, 498, 34);
		add(textHome_1_1_1);
		
		JLabel textHome_1_1_1_1 = new JLabel("your home remains marked with your presence and provides you with all the necessary");
		textHome_1_1_1_1.setForeground(new Color(255, 255, 255));
		textHome_1_1_1_1.setBounds(40, 274, 498, 34);
		add(textHome_1_1_1_1);
		
		JLabel textHome_1_1_1_1_1 = new JLabel("information. Economy of heating, safety are among the topics most requested by");
		textHome_1_1_1_1_1.setForeground(new Color(255, 255, 255));
		textHome_1_1_1_1_1.setBounds(40, 293, 498, 34);
		add(textHome_1_1_1_1_1);
		
		JLabel textHome_1_1_1_1_1_1 = new JLabel("consumers but the need is sometimes created by the manufacturers themselves.");
		textHome_1_1_1_1_1_1.setForeground(new Color(255, 255, 255));
		textHome_1_1_1_1_1_1.setBounds(40, 319, 498, 34);
		add(textHome_1_1_1_1_1_1);

	}
}
