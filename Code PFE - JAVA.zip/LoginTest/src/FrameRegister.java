import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Panel;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.SwingConstants;

public class FrameRegister extends JFrame {
	private Image img_logo = new ImageIcon(FrameLogin.class.getResource("res/logo.png")).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
	private Image img_user = new ImageIcon(FrameLogin.class.getResource("res/man.png")).getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
	private Image img_mail = new ImageIcon(FrameLogin.class.getResource("res/logo.png")).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
	private Image img_pass = new ImageIcon(FrameLogin.class.getResource("res/padlock.png")).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
	private Image img_login = new ImageIcon(FrameLogin.class.getResource("res/icon.png")).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);

	private JPanel contentPane;
	private JTextField Username;
	private JTextField mail;
	private JPasswordField Password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameRegister frame = new FrameRegister();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrameRegister() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 259, 333);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Username = new JTextField();
		Username.setBorder(null);
		Username.setBounds(10, 70, 199, 30);
		contentPane.add(Username);
		Username.setColumns(10);
		
		mail = new JTextField();
		mail.setBorder(null);
		mail.setColumns(10);
		mail.setBounds(10, 130, 199, 30);
		contentPane.add(mail);
		
		JLabel UserNamelbl = new JLabel("Username : ");
		UserNamelbl.setForeground(new Color(255, 255, 255));
		UserNamelbl.setBounds(10, 54, 72, 14);
		contentPane.add(UserNamelbl);
		
		JLabel maillbl = new JLabel("Mail : ");
		maillbl.setForeground(new Color(255, 255, 255));
		maillbl.setBounds(10, 116, 72, 14);
		contentPane.add(maillbl);
		
		JLabel Passwordlbl = new JLabel("Password : ");
		Passwordlbl.setForeground(new Color(255, 255, 255));
		Passwordlbl.setBounds(10, 174, 72, 14);
		contentPane.add(Passwordlbl);
		
		JButton btnNewButton = new JButton("Registration");
		btnNewButton.setBackground(new Color(47, 79, 79));
		btnNewButton.setForeground(new Color(255, 255, 255));
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					Class.forName("com.mysql.jdbc.Driver"); 
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
					PreparedStatement ps = conn.prepareStatement("insert into tblogin(UserName,mail,Password ) values (?,?,?);");
					ps.setString(1, Username.getText());
					ps.setString(2, mail.getText());
					ps.setString(3, Password.getText());
					int x = ps.executeUpdate();
					if (x == 0) {
	                       JOptionPane.showMessageDialog(btnNewButton, "This is alredy exist");
	                    	
	                    } else {
	                        JOptionPane.showMessageDialog(btnNewButton,
	                             "Your account is sucessfully created");
	                    	
	                    }
	                    conn.close();
				} catch (Exception e) {
					System.out.print(e);
				}
			}
		});
		btnNewButton.setBounds(20, 227, 107, 29);
		contentPane.add(btnNewButton);
		
		Password = new JPasswordField();
		Password.setBorder(null);
		Password.setBounds(10, 187, 199, 29);
		contentPane.add(Password);
		
		JLabel labellogo = new JLabel("");
		labellogo.setHorizontalAlignment(SwingConstants.CENTER);
		labellogo.setIcon(new ImageIcon(img_logo));
		labellogo.setBounds(47, 5, 128, 48);
		contentPane.add(labellogo);
		
		JLabel lblUserName = new JLabel("New label");
		lblUserName.setBounds(163, 70, 46, 30);
		lblUserName.setIcon(new ImageIcon(img_user));
		contentPane.add(lblUserName);
		
	}
}
