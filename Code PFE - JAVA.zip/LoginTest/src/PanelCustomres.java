import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;

public class PanelCustomres extends JPanel {
	// Variables declaration - do not modify                     
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration  
    SerialCommunication com=new SerialCommunication();
    private int onred,ongreen,onblue,gaz,servo = 0 ;
    private JButton btnNewButton;
    private JTextField textField3;
	/**
	 * Create the panel.
	 */
//	public PanelCustomres(GroupLayout layout, Container container) {
    public PanelCustomres() {
		setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		setBackground(new Color(0, 128, 128));

		setBounds(0,0,538,396);
//		this.com = com;
		
		setLayout(null);
		jButton1 = new javax.swing.JButton();
		jButton1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		jButton1.setFont(new Font("Arial", Font.ITALIC, 13));
        jButton1.setBackground(new Color(139, 69, 19));
        jButton1.setBounds(26, 11, 135, 40);
        jButton1.setForeground(new Color(255, 255, 255));
        add(jButton1);
        jButton2 = new javax.swing.JButton();
        jButton2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        jButton2.setFont(new Font("Arial", Font.ITALIC, 13));
        jButton2.setForeground(new Color(255, 255, 255));
        jButton2.setBackground(new Color(255, 0, 0));
        jButton2.setBounds(171, 11, 135, 40);
        add(jButton2);
        jButton21 = new javax.swing.JButton();
        jButton21.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        jButton21.setFont(new Font("Arial", Font.ITALIC, 13));
        jButton21.setBounds(26, 62, 135, 40);
        jButton21.setForeground(new Color(255, 255, 255));
        jButton21.setBackground(new Color(0, 0, 128));
        add(jButton21);
        jButton22 = new javax.swing.JButton();
        jButton22.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        jButton22.setFont(new Font("Arial", Font.ITALIC, 13));
        jButton22.setForeground(new Color(255, 255, 255));
        jButton22.setBounds(316, 11, 135, 40);
        jButton22.setBackground(new Color(0, 100, 0));
        add(jButton22);
        jButton3 = new javax.swing.JButton();
        jButton3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        jButton3.setFont(new Font("Arial", Font.ITALIC, 13));
        jButton3.setBounds(26, 113, 135, 40);
        jButton3.setForeground(new Color(0, 0, 0));
        jButton3.setBackground(new Color(255, 255, 255));
        add(jButton3);
        jButton4 = new javax.swing.JButton();
        jButton4.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        jButton4.setFont(new Font("Arial", Font.ITALIC, 13));
        jButton4.setForeground(new Color(0, 0, 0));
        jButton4.setBounds(171, 62, 135, 40);
        jButton4.setBackground(new Color(255, 255, 0));
        add(jButton4);
        jLabel1 = new javax.swing.JLabel();
        jLabel1.setForeground(new Color(255, 255, 255));
        jLabel1.setFont(new Font("Arial", Font.ITALIC, 13));
        jLabel1.setBounds(26, 181, 91, 40);
        jLabel2 = new javax.swing.JLabel();
        jLabel2.setForeground(new Color(255, 255, 255));
        jLabel2.setFont(new Font("Arial", Font.ITALIC, 13));
        jLabel2.setBounds(36, 232, 91, 40);
        add(jLabel1);
        add(jLabel2);
        jTextField1 = new javax.swing.JTextField();
        jTextField1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
        jTextField1.setHorizontalAlignment(SwingConstants.CENTER);
        jTextField1.setBounds(171, 190, 135, 25);
        jTextField2 = new javax.swing.JTextField();
        jTextField2.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
        jTextField2.setHorizontalAlignment(SwingConstants.CENTER);
        jTextField2.setBounds(171, 241, 135, 25);
        add(jTextField1);
        add(jTextField2);
        jButton1.setText("OFF-BUZZER");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                if(gaz == 0) {
                	com.write("0");
                	gaz = 1 ; 
                } else {
                	com.write("1");
                	gaz = 0 ; 
                }
            }
        });
        //7
        jButton2.setText("PIN 7");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	if(ongreen == 0) {
            		com.write("a");
            		ongreen = 1;
				}else {
					com.write("b");
					ongreen = 0;
				}
            } 
        });
        //13
        jButton21.setText("PIN 13");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	if(onred == 0) {
            		com.write("c");
					onred = 1;
				}else {
					com.write("d");
					onred = 0;
				}
            }
        });
        
        jButton22.setText("PIN 3");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	if(onblue == 0) {
            		com.write("e");
            		onblue = 1;
				}else {
					com.write("f");
					onblue = 0;
				}
            }
        });
        
        


        jButton3.setText("TEMP & HUMID");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
                jTextField1.setText(""+com.temp);
                jTextField2.setText(""+com.hum);
            }
        });

        jButton4.setText("SERVO-MOTOR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
               if(servo == 0) {
            	   com.write("g");
            	   servo = 1 ; 
            	   
               } else {
            	   com.write("h");
            	   servo = 0 ; 
               }
            }
        });

        jLabel1.setText("La temp�rature");

        jLabel2.setText("L'humidit�");
        
        btnNewButton = new JButton("CO");
        btnNewButton.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        btnNewButton.setFont(new Font("Arial", Font.ITALIC, 13));
        btnNewButton.setBackground(new Color(0, 0, 0));
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        	   textField3.setText(""+com.co);
        	}
        });
        btnNewButton.setBounds(171, 113, 135, 37);
        add(btnNewButton);
        
        JLabel lblMonoxydeDeCarbone = new JLabel("Monoxyde de carbone");
        lblMonoxydeDeCarbone.setForeground(new Color(255, 255, 255));
        lblMonoxydeDeCarbone.setFont(new Font("Arial", Font.ITALIC, 13));
        lblMonoxydeDeCarbone.setBounds(26, 296, 135, 14);
        add(lblMonoxydeDeCarbone);
        
        textField3 = new JTextField();
        textField3.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
        textField3.setHorizontalAlignment(SwingConstants.CENTER);
        textField3.setBounds(171, 292, 135, 25);
        add(textField3);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
               jTextField1ActionPerformed(evt);
            }
        });
        
//        layout.setHorizontalGroup(
//        	layout.createParallelGroup(Alignment.LEADING)
//        		.addGroup(layout.createSequentialGroup()
//        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
//        				.addGroup(layout.createSequentialGroup()
//        					.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
//        					.addGap(18)
//        					.addComponent(jButton21, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
//        					.addGap(18)
//        					.addComponent(jButton22, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
//        					.addGap(18)
//        					.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
//        					.addGap(18)
//        					.addComponent(jButton3, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
//        					.addGap(18)
//        					.addComponent(jButton4, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
//        				.addGroup(layout.createSequentialGroup()
//        					.addGap(20)
//        					.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
//        						.addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
//        						.addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
//        					.addPreferredGap(ComponentPlacement.UNRELATED)
//        					.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
//        						.addComponent(jTextField1, GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
//        						.addComponent(jTextField2))))
//        			.addContainerGap(38, Short.MAX_VALUE))
//        );
//        layout.setVerticalGroup(
//        	layout.createParallelGroup(Alignment.LEADING)
//        		.addGroup(layout.createSequentialGroup()
//        			.addGap(25)
//        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
//        				.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
//        				.addComponent(jButton21, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
//        				.addComponent(jButton22, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
//        				.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
//        				.addComponent(jButton3, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
//        				.addComponent(jButton4, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE))
//        			.addGap(36)
//        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
//        				.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
//        				.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
//        			.addPreferredGap(ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
//        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
//        				.addComponent(jLabel2)
//        				.addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
//        			.addGap(134))
//        );
//        container.setLayout(layout);
        
	}
	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
    	
    }                                        

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
    }
    
    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }    
}
