import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class FrameLogin extends JFrame {

private Image img_logo = new ImageIcon(FrameLogin.class.getResource("res/logo.png")).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
private Image img_username = new ImageIcon(FrameLogin.class.getResource("res/man.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
private Image img_password = new ImageIcon(FrameLogin.class.getResource("res/padlock.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
private Image img_log_in = new ImageIcon(FrameLogin.class.getResource("res/icon.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);



	private JPanel contentPane;
	private JTextField tstUsername; 
	private JPasswordField txtPassword;
	private JLabel lblLoginMessage = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrameLogin frame = new FrameLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrameLogin() {
	    setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setFont(new Font("Arial", Font.PLAIN, 11));
		contentPane.setForeground(new Color(165, 42, 42));
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 128), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(175, 167, 250, 40);
		contentPane.add(panel);
		panel.setLayout(null);
		
		tstUsername = new JTextField();
		tstUsername.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				if(tstUsername.getText().equals("Username")) {
					tstUsername.setText("");
				}
				else {
					tstUsername.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(tstUsername.getText().equals(""))
				tstUsername.setText("Username");	
			}
		});
		tstUsername.setBorder(null);
		tstUsername.setFont(new Font("Arial", Font.PLAIN, 12));
		tstUsername.setText("Username");
		tstUsername.setBounds(10, 11, 170, 20);
		panel.add(tstUsername);
		tstUsername.setColumns(10);
		
		JLabel lblIconUsername = new JLabel("");
		lblIconUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconUsername.setBounds(210, 0, 40, 40);
		lblIconUsername.setIcon(new ImageIcon(img_username));
		panel.add(lblIconUsername);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(175, 218, 250, 40);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		txtPassword = new JPasswordField();
		txtPassword.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(txtPassword.getText().equals("Password")) {
					txtPassword.setEchoChar('●');
					txtPassword.setText("");
				}
				else {
					txtPassword.selectAll();
				}
				
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtPassword.getText().equals(""))
					txtPassword.setText("Passsword");
				txtPassword.setEchoChar((char)0);
			}
		});
		txtPassword.setBorder(null);
		txtPassword.setEchoChar((char)0);
		txtPassword.setFont(new Font("Arial", Font.PLAIN, 12));
		txtPassword.setText("Password");
		txtPassword.setBounds(new Rectangle(0, 0, 0, 20));
		txtPassword.setBounds(10, 11, 170, 20);
		panel_1.add(txtPassword);
		
		JLabel lblIconPassword = new JLabel("");
		lblIconPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconPassword.setBounds(210, 0, 40, 40);
		lblIconPassword.setIcon(new ImageIcon(img_password));
		panel_1.add(lblIconPassword);
		
		JPanel pnlBtnLogin = new JPanel();
		pnlBtnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver"); 
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
					java.sql.Statement stmt = con.createStatement();
					String sql = " Select * from tblogin where UserName='"+tstUsername.getText()+"' and Password='"+txtPassword.getText().toString()+"'";
					ResultSet rs = stmt.executeQuery(sql); 
					if(rs.next()) {
						lblLoginMessage.setText("");
						//JOptionPane.showMessageDialog(null," Login Successfuly");
						FrameDashboard k = new FrameDashboard();
						k.setVisible(true);
					
					}
					else if(tstUsername.getText().equals("") || tstUsername.getText().equals("Username")  ||
					        txtPassword.getText().equals("") || txtPassword.getText().equals("Password")) {
						lblLoginMessage.setText("Please input all requirements ! ");
					}
					else {
						lblLoginMessage.setText("Sorry , Check your Username or Password  ! ");
						con.close();
					}
				} catch (Exception e) {
					System.out.print(e); 
				}
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				pnlBtnLogin.setBackground(new Color(30, 60, 60));

			}
			@Override
			public void mouseExited(MouseEvent e) {
				pnlBtnLogin.setBackground(new Color(47, 79, 79));

			}
			@Override
			public void mousePressed(MouseEvent e) {
				pnlBtnLogin.setBackground(new Color(60, 80, 80));

			}
			@Override
			public void mouseReleased(MouseEvent e) {
				pnlBtnLogin.setBackground(new Color(30, 60, 60));

			}
		});
		pnlBtnLogin.setBackground(new Color(47, 79, 79));
		pnlBtnLogin.setBounds(175, 298, 255, 50);
		contentPane.add(pnlBtnLogin);
		pnlBtnLogin.setLayout(null);
		
		JLabel lblLogin = new JLabel("LOGIN");
		lblLogin.setForeground(Color.WHITE);
		lblLogin.setBackground(Color.PINK);
		lblLogin.setFont(new Font("Arial", Font.BOLD, 14));
		lblLogin.setBounds(105, 11, 90, 28);
		pnlBtnLogin.add(lblLogin);
		
		JLabel lblIconLogin = new JLabel("");
		lblIconLogin.setBounds(53, 0, 63, 50);
		lblIconLogin.setIcon(new ImageIcon(img_log_in));
		pnlBtnLogin.add(lblIconLogin);
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
if(JOptionPane.showConfirmDialog(null, "Are you sure you want to close this application ? ", "Confirmation", JOptionPane.YES_NO_OPTION) == 0) {
					FrameLogin.this.dispose();
				}
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				lblX.setForeground(Color.RED);
			}
			public void mouseExited(MouseEvent arg0) {
				lblX.setForeground(Color.WHITE);
			}
		});
		lblX.setForeground(Color.WHITE);
		lblX.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setBounds(580, 0, 20, 20);
		contentPane.add(lblX);
		
		JLabel lblIconLogo = new JLabel("");
		lblIconLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblIconLogo.setBounds(175, 42, 250, 111);
		contentPane.add(lblIconLogo);
		lblIconLogo.setIcon(new ImageIcon(img_logo));
		
		lblLoginMessage.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblLoginMessage.setForeground(new Color(128, 0, 0));
		lblLoginMessage.setBounds(174, 267, 251, 20);
		contentPane.add(lblLoginMessage);
		
		JLabel lblClickHereTo = new JLabel("Click here To Register ");
		lblClickHereTo.setFont(new Font("Arial", Font.PLAIN, 13));
		lblClickHereTo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Register fr =new Register(); 
				fr.setVisible(true);
				
			}
		});
		lblClickHereTo.setForeground(new Color(128, 0, 0));
		lblClickHereTo.setHorizontalAlignment(SwingConstants.CENTER);
		lblClickHereTo.setBounds(240, 365, 145, 14);
		contentPane.add(lblClickHereTo);
		setLocationRelativeTo(null);
	}
}
