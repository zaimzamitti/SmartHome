import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Color;

public class PanelSettings extends JPanel {

	private Image img_CO = new ImageIcon(FrameLogin.class.getResource("res/maxresdefault.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_temp = new ImageIcon(FrameLogin.class.getResource("res/temp.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_humid = new ImageIcon(FrameLogin.class.getResource("res/humd.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_led = new ImageIcon(FrameLogin.class.getResource("res/14973-200.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_venti = new ImageIcon(FrameLogin.class.getResource("res/247166-200.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);

	public PanelSettings() {
		setBackground(new Color(0, 128, 128));
		setBounds(0,0,538,396);
		setLayout(null);
		
		JLabel CO = new JLabel("");
		CO.setIcon(new ImageIcon(img_CO));
		CO.setHorizontalAlignment(SwingConstants.CENTER);
		CO.setFont(new Font("Tahoma", Font.BOLD, 37));
		CO.setBounds(10, 19, 133, 150);
		add(CO);
		
		JLabel lblNewLabel = new JLabel("Detection 'CO'");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(20, 180, 111, 25);
		add(lblNewLabel);
		
		JLabel temp = new JLabel("");
		temp.setIcon(new ImageIcon(img_temp));
		temp.setHorizontalAlignment(SwingConstants.CENTER);
		temp.setFont(new Font("Tahoma", Font.BOLD, 37));
		temp.setBounds(174, 34, 121, 135);
		add(temp);
		
		JLabel lblDetectiontemprature = new JLabel("Detection 'temp\'");
		lblDetectiontemprature.setForeground(new Color(255, 255, 255));
		lblDetectiontemprature.setHorizontalAlignment(SwingConstants.CENTER);
		lblDetectiontemprature.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDetectiontemprature.setBounds(174, 180, 111, 25);
		add(lblDetectiontemprature);
		
		JLabel humid = new JLabel("");
		humid.setIcon(new ImageIcon(img_humid));
		humid.setHorizontalAlignment(SwingConstants.CENTER);
		humid.setFont(new Font("Tahoma", Font.BOLD, 37));
		humid.setBounds(357, 19, 140, 150);
		add(humid);
		
		JLabel humi = new JLabel("Detection 'Humd'");
		humi.setForeground(new Color(255, 255, 255));
		humi.setHorizontalAlignment(SwingConstants.CENTER);
		humi.setFont(new Font("Tahoma", Font.BOLD, 11));
		humi.setBounds(386, 180, 111, 25);
		add(humi);
		
		JLabel led = new JLabel("");
		led.setIcon(new ImageIcon(img_led));
		led.setHorizontalAlignment(SwingConstants.CENTER);
		led.setFont(new Font("Tahoma", Font.BOLD, 37));
		led.setBounds(63, 228, 130, 135);
		add(led);
		
		JLabel lblNewLabel_1 = new JLabel("Allumer 'LED'");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(73, 360, 111, 25);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Ventilation");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(346, 360, 111, 25);
		add(lblNewLabel_2);
		
		JLabel venti = new JLabel("");
		venti.setIcon(new ImageIcon(img_venti));
		venti.setHorizontalAlignment(SwingConstants.CENTER);
		venti.setFont(new Font("Tahoma", Font.BOLD, 37));
		venti.setBounds(328, 228, 156, 135);
		add(venti);

	}

}
