


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.JTextArea;

import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;
import jssc.SerialPortList;

public class SerialCommunication implements SerialPortEventListener {  
	SerialPort serialPort;
	double temp;
	double hum;
	double co; 
	String chaine_recue="";
    
	public SerialCommunication() {
		serialPort = new SerialPort("COM5");
		//board.setVisible(true);
		// les ports disponibles
		// String[] portNames = SerialPortList.getPortNames();
		// for (int i = 0; i < portNames.length; i++) {
		// System.out.println(portNames[i]);
		// }

		try {
			serialPort.openPort();
			serialPort.setParams(9600, 8, 1, 0);
			serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN | SerialPort.FLOWCONTROL_RTSCTS_OUT);
			serialPort.addEventListener(this, SerialPort.MASK_RXCHAR);
		} catch (SerialPortException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void write(String arg) {

		try {
			serialPort.writeBytes(arg.getBytes());
			
			//byte octet=  (byte) 0b11000100;
			//serialPort.writeByte(octet);

			} catch (SerialPortException ex) {
			System.out.println(ex);
									}

	}

	@Override
	public void serialEvent(SerialPortEvent event) {
		if(event.getEventValue()>0) {
	          

			try {
				byte[] receivedData = serialPort.readBytes();
				      for(int i=0; i <receivedData.length; i++ ) {
				    	  char c=(char)receivedData[i];
				    	  switch (c) {
				    	  case 'h' : {
				    		           hum=Double.parseDouble(chaine_recue);
				    		           chaine_recue="";
				    		           break;
				    		  
				    	            }
				    	  case 'o' : {
		    		           co=Double.parseDouble(chaine_recue);
		    		           chaine_recue="";
		    		           break;
		    		  
		    	            }
				    	  case 't' : {
				    		         temp=Double.parseDouble(chaine_recue);
		    		                 chaine_recue="";
		    		                 break;
				    		  
		    	            }
				    	  
				    	  default: {
				    		  chaine_recue=chaine_recue+c;
				    		  break;
				    		  
				    	           }
				    	  }
				    	  }
				    	  
				    	 try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			} catch (SerialPortException ex) {
				System.out.println("Error in receiving string from COM-port: " + ex);
			}
			System.out.println("Humidity & temperature & Co Sensor :   "); 
			System.out.println("temp�rature: " + temp);
			System.out.println("humidity: " + hum);
			System.out.println("Co : " + co);
			
		
			}
		
		

		}

	

	/*public static void main(String[] args) {
		SerialCommunication connector = new SerialCommunication();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread thread = new Thread() {
			public void run() {
				while (true) {
					connector.write("b");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} 
					connector.write("");
					
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} 

		};
		 thread.start();
		//connector.write("A");
	}*/
	
	/*SerialCommunication connector = new SerialCommunication();

	public void run2(String k ) {
		while (true) {
			if(k.equals("1")) {
			connector.write("1");
			} else {
				connector.write("0");
			}
		}
		
	}*/
	public void closeSerialConnexion() {
		try {
			
			serialPort.closePort();
		} catch (SerialPortException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}
		
	}
	 

     


