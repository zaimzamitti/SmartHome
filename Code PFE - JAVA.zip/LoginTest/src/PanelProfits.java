import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Color;

public class PanelProfits extends JPanel {

	private Image img_arduino = new ImageIcon(FrameLogin.class.getResource("res/1.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_buzzer = new ImageIcon(FrameLogin.class.getResource("res/2.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_dht22= new ImageIcon(FrameLogin.class.getResource("res/3.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_mq7 = new ImageIcon(FrameLogin.class.getResource("res/4.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);
	private Image img_servo_motor = new ImageIcon(FrameLogin.class.getResource("res/5.png")).getImage().getScaledInstance(220, 150, Image.SCALE_SMOOTH);

	public PanelProfits() {
		setBackground(new Color(0, 128, 128));
		setBounds(0,0,538,396);
		setLayout(null);
		
		JLabel arduino = new JLabel("");
		arduino.setIcon(new ImageIcon(img_arduino));
		arduino.setBounds(10, 29, 191, 136);
		add(arduino);
		
		JLabel mq7 = new JLabel("");
		mq7.setIcon(new ImageIcon(img_mq7));
		mq7.setBounds(211, 29, 165, 136);
		add(mq7);
		
		JLabel dht22 = new JLabel("");
		dht22.setIcon(new ImageIcon(img_dht22));
		dht22.setBounds(403, 29, 125, 136);
		add(dht22);
		
		JLabel buzzer = new JLabel("");
		buzzer.setIcon(new ImageIcon(img_buzzer));
		buzzer.setBounds(74, 241, 156, 113);
		add(buzzer);
		
		JLabel servo = new JLabel("");
		servo.setIcon(new ImageIcon(img_servo_motor));
		servo.setBounds(337, 218, 191, 136);
		add(servo);
		
		JLabel lblNewLabel = new JLabel("Carte Arduino UNO");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(32, 176, 114, 31);
		add(lblNewLabel);
		
		JLabel lblMqSensor = new JLabel("SERVO MOTOR");
		lblMqSensor.setForeground(new Color(255, 255, 255));
		lblMqSensor.setFont(new Font("Arial", Font.PLAIN, 12));
		lblMqSensor.setHorizontalAlignment(SwingConstants.CENTER);
		lblMqSensor.setBounds(231, 176, 114, 31);
		add(lblMqSensor);
		
		JLabel lblDhtSensor = new JLabel("DHT22 Sensor");
		lblDhtSensor.setForeground(new Color(255, 255, 255));
		lblDhtSensor.setFont(new Font("Arial", Font.PLAIN, 12));
		lblDhtSensor.setHorizontalAlignment(SwingConstants.CENTER);
		lblDhtSensor.setBounds(413, 176, 114, 31);
		add(lblDhtSensor);
		
		JLabel lblBuzzer = new JLabel("Buzzer");
		lblBuzzer.setForeground(new Color(255, 255, 255));
		lblBuzzer.setFont(new Font("Arial", Font.PLAIN, 12));
		lblBuzzer.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuzzer.setBounds(95, 354, 114, 31);
		add(lblBuzzer);
		
		JLabel lblServoMotor = new JLabel("MQ7 Sensor");
		lblServoMotor.setForeground(new Color(255, 255, 255));
		lblServoMotor.setFont(new Font("Arial", Font.PLAIN, 12));
		lblServoMotor.setHorizontalAlignment(SwingConstants.CENTER);
		lblServoMotor.setBounds(367, 354, 114, 31);
		add(lblServoMotor);
	}
}
